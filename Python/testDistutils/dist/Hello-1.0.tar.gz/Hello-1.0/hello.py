#coding=utf-8
print 'Hello World'